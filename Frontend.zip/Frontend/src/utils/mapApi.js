import axios from 'axios';
import { getCaptainAuthHeaders, getUserAuthHeaders } from './authStorage';

const GEOCODE_CACHE_TTL_MS = 10 * 60 * 1000;
const ROUTE_CACHE_TTL_MS = 15 * 1000;
const geocodeCache = new Map();
const routeCache = new Map();
const geocodeInFlightRequests = new Map();
const routeInFlightRequests = new Map();

const getAuthHeaders = (role = 'user') => {
  if (role === 'captain') {
    return getCaptainAuthHeaders();
  }

  return getUserAuthHeaders();
};

export const normalizeMapCoordinate = (point) => {
  if (!point || typeof point !== 'object') {
    return null;
  }

  const latitude = Number(point.lat ?? point.ltd ?? point.latitude);
  const longitude = Number(point.lng ?? point.lon ?? point.longitude);

  if (Number.isNaN(latitude) || Number.isNaN(longitude)) {
    return null;
  }

  return {
    lat: latitude,
    lng: longitude,
  };
};

export const hasCoordinates = (point) => Boolean(normalizeMapCoordinate(point));

const buildLocationCacheKey = (location) => {
  if (typeof location === 'string' && location.trim()) {
    return location.trim().toLowerCase();
  }

  const normalizedCoordinate = normalizeMapCoordinate(location);

  if (!normalizedCoordinate) {
    return '';
  }

  return `${normalizedCoordinate.lat.toFixed(6)},${normalizedCoordinate.lng.toFixed(6)}`;
};

const readCachedValue = (cache, key) => {
  if (!key) {
    return null;
  }

  const cachedEntry = cache.get(key);

  if (!cachedEntry) {
    return null;
  }

  if (cachedEntry.expiresAt <= Date.now()) {
    cache.delete(key);
    return null;
  }

  return cachedEntry.value;
};

const writeCachedValue = (cache, key, value, ttlMs) => {
  if (!key) {
    return value;
  }

  cache.set(key, {
    value,
    expiresAt: Date.now() + ttlMs,
  });

  return value;
};

const buildRouteCacheKey = ({ origin, destination, waypoints = [], role = 'user' }) =>
  [
    role,
    buildLocationCacheKey(origin),
    buildLocationCacheKey(destination),
    ...(Array.isArray(waypoints) ? waypoints.map((waypoint) => buildLocationCacheKey(waypoint)) : []),
  ].join('::');

const parseCoordinateString = (value) => {
  if (typeof value !== 'string') {
    return null;
  }

  const trimmedValue = value.trim();

  if (!trimmedValue) {
    return null;
  }

  const coordinateMatch = trimmedValue.match(/^(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)$/);

  if (!coordinateMatch) {
    return null;
  }

  const latitude = Number(coordinateMatch[1]);
  const longitude = Number(coordinateMatch[2]);

  if (
    Number.isNaN(latitude) ||
    Number.isNaN(longitude) ||
    latitude < -90 ||
    latitude > 90 ||
    longitude < -180 ||
    longitude > 180
  ) {
    return null;
  }

  return {
    lat: latitude,
    lng: longitude,
  };
};

export const formatDistanceText = (distanceMeters) => {
  const normalizedDistanceMeters = Number(distanceMeters);

  if (!Number.isFinite(normalizedDistanceMeters) || normalizedDistanceMeters <= 0) {
    return '';
  }

  if (normalizedDistanceMeters < 1000) {
    return `${Math.round(normalizedDistanceMeters)} m`;
  }

  const distanceKilometers = normalizedDistanceMeters / 1000;
  const formattedDistance =
    distanceKilometers >= 10 ? distanceKilometers.toFixed(0) : distanceKilometers.toFixed(1);

  return `${formattedDistance} km`;
};

export const formatDurationText = (durationSeconds) => {
  const normalizedDurationSeconds = Number(durationSeconds);

  if (!Number.isFinite(normalizedDurationSeconds) || normalizedDurationSeconds <= 0) {
    return '';
  }

  const totalMinutes = Math.max(1, Math.round(normalizedDurationSeconds / 60));

  if (totalMinutes < 60) {
    return `${totalMinutes} mins`;
  }

  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;

  if (!minutes) {
    return `${hours} hr`;
  }

  return `${hours} hr ${minutes} mins`;
};

const normalizeRouteData = (data = {}) => ({
  ...data,
  totalDistanceMeters: Number(data?.totalDistanceMeters) || 0,
  totalDurationSeconds: Number(data?.totalDurationSeconds) || 0,
  coordinates: Array.isArray(data?.coordinates)
    ? data.coordinates.map((coordinate) => normalizeMapCoordinate(coordinate)).filter(Boolean)
    : [],
  legs: Array.isArray(data?.legs)
    ? data.legs.map((leg) => ({
        ...leg,
        distanceMeters: Number(leg?.distanceMeters) || 0,
        durationSeconds: Number(leg?.durationSeconds) || 0,
        startLocation: normalizeMapCoordinate(leg?.startLocation),
        endLocation: normalizeMapCoordinate(leg?.endLocation),
      }))
    : [],
});

export const getMapCoordinates = async (address, options = {}) => {
  const { role = 'user' } = options;
  const coordinateFromString = parseCoordinateString(address);

  if (coordinateFromString) {
    return coordinateFromString;
  }

  const cacheKey = `${role}::${buildLocationCacheKey(address)}`;
  const cachedCoordinate = readCachedValue(geocodeCache, cacheKey);

  if (cachedCoordinate) {
    return cachedCoordinate;
  }

  if (geocodeInFlightRequests.has(cacheKey)) {
    return geocodeInFlightRequests.get(cacheKey);
  }

  const coordinateRequest = axios
    .get(`${import.meta.env.VITE_BASE_URL}/maps/get-coordinates`, {
      params: {
        address,
      },
      headers: getAuthHeaders(role),
    })
    .then(({ data }) =>
      writeCachedValue(
        geocodeCache,
        cacheKey,
        normalizeMapCoordinate(data),
        GEOCODE_CACHE_TTL_MS
      )
    )
    .finally(() => {
      geocodeInFlightRequests.delete(cacheKey);
    });

  geocodeInFlightRequests.set(cacheKey, coordinateRequest);
  return coordinateRequest;
};

export const getMapRoute = async ({ origin, destination, waypoints = [], role = 'user' }) => {
  const cacheKey = buildRouteCacheKey({ origin, destination, waypoints, role });
  const cachedRoute = readCachedValue(routeCache, cacheKey);

  if (cachedRoute) {
    return cachedRoute;
  }

  if (routeInFlightRequests.has(cacheKey)) {
    return routeInFlightRequests.get(cacheKey);
  }

  const routeRequest = axios
    .post(
      `${import.meta.env.VITE_BASE_URL}/maps/get-route`,
      {
        origin,
        destination,
        waypoints,
      },
      {
        headers: getAuthHeaders(role),
      }
    )
    .then(({ data }) =>
      writeCachedValue(routeCache, cacheKey, normalizeRouteData(data), ROUTE_CACHE_TTL_MS)
    )
    .finally(() => {
      routeInFlightRequests.delete(cacheKey);
    });

  routeInFlightRequests.set(cacheKey, routeRequest);
  return routeRequest;
};
